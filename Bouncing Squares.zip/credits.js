/*

// Main Game Music
"Jerry Five" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
http://creativecommons.org/licenses/by/4.0/

"Cool Blast" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
http://creativecommons.org/licenses/by/4.0/

"Special Spotlight" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
http://creativecommons.org/licenses/by/4.0/

"Vicious" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
http://creativecommons.org/licenses/by/4.0/

"Blobby Samba" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
http://creativecommons.org/licenses/by/4.0/

// Sound Effects
"Get Powerup", "Enemy Split" from https://mixkit.co/free-sound-effects/game/

"Pacman Start Sound Effect" from https://www.youtube.com/watch?v=lmoKw4eJzik&ab_channel=SoundEffectsLibrary

"Jojo Stop Time Sound Effect" from https://www.youtube.com/watch?v=TWtJ0VUsuZo&ab_channel=Rotanux

"Slice Sound" from https://www.youtube.com/watch?v=dxb2mY0zQZs&ab_channel=SoundLibrary























*/